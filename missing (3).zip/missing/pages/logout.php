<?php
    session_start();
    header("Content-Type:text/html; charset=utf-8");
    
    //將session清空
    unset($_SESSION['uId']);
    echo '登出中';
	header("Location:index.php");
?>