<?php
    session_start(); 
    
    header("Content-Type:text/html; charset=utf-8");
   
    if(!(isset($_POST["email"])&isset($_POST["password"]))){
        	echo "nodata";
    }
    $email=$_POST["email"];
    $password=$_POST["password"];

    //echo $email." ".$password." ".$name;
	
	require_once "config.php";

	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
	$result = mysql_query ( "set names utf8", $link );
	mysql_selectdb ( $dbname, $link );
    //
 	$cmd = "SELECT * FROM `user` WHERE `email` = '$email' and `password`='$password'";
	$result=mysql_query($cmd,$link);
    if (mysql_num_rows($result) < 1){
        //echo "沒有此帳號";
        echo "帳號或密碼輸入錯誤";
        header("Location:login.php");
    }else{
        $row = mysql_fetch_assoc($result);
        $uId =  $row['uId'];  
        $_SESSION['uId'] = $uId;
        header("Location:index.php");
    }
?>