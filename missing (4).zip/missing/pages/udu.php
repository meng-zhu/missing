<?php 
    session_start();
    header("Content-Type:text/html; charset=utf-8");
    
    $uId = $_SESSION['uId'];
    $password=$_POST["password"];
    $password1=$_POST["password1"];
    $name=$_POST["name"];
    $phone=$_POST["phone"];
    
    if($password != $password1){//再次確認密碼是否輸入一致
        echo "確認密碼錯誤";
        header("Location:mdm.php");

    }else{
        require_once "config.php";

    	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
    	$result = mysql_query ( "set names utf8", $link );
    	mysql_selectdb ( $dbname, $link );
            
        if($password != null){//如果有改密碼
           
         	$cmd = "UPDATE `user` SET `password`='$password',`name`='$name',`phone`='$phone' WHERE `uId` ='$uId'";
        
        }else{//沒改密碼
            
         	$cmd = "UPDATE `user` SET `name`='$name',`phone`='$phone' WHERE `uId` ='$uId'";
        
        }
        	$result=mysql_query($cmd,$link);
            echo "會員資料已變更";
            header("Location:index.php");
       
    }
    
?>

