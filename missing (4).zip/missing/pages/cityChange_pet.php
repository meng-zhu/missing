<?php

    if (! (isset($_GET["city"])&isset($_GET["type"]))) {
    	die("no city found.");
    }
    
    $type = $_GET["type"];
    $city = $_GET["city"];
    

    if($city != "請選擇縣市"){
        $cmd =  "select * from pet , user where pet.uId=user.uId and city like '".$city."%' and  type ='".$type."' order by pet.poDate desc";
    }else{
        $cmd = "select * from pet , user where pet.uId=user.uId and type = '".$type."' order by pet.poDate desc";
    }

	require_once "config.php";

	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
	$result = mysql_query ( "set names utf8", $link );
	mysql_selectdb ( $dbname, $link );
	$result=mysql_query($cmd,$link);

    
?>
    <ul data-role="listview" data-filter="true">
        <table width="80%">
            <?php while ($row = mysql_fetch_assoc($result)){ ?>
                <tr>
                    <td align="center">
                        <img src="images/<?php echo $row['images']?>"  width="250" height="250"> 
                    </td>
                    <td>
                        <h6><?php 
        			    echo "晶片編號： " . $row['num'] . "<br><br>品種： " . $row['variety']	. "<br><br>性別： " . $row['sex'] . "  體重： " . $row['weight'] . "  年齡： " . $row['age']	. "  顏色： " . $row['color'] . "<br><br>其他特徵： " . $row['orther'] .  "<br><br>失蹤日期： " . $row['missingDate'] . "<br><br>失蹤地點： " . $row['missingPlace'] . "<br><br>聯絡人： " . $row['name'] . "<br><br>聯絡電話： " . $row['phone'] . "<br><br>Email： " . $row['email'] . "<br><br>發佈日期： " . $row['poDate'];
            		       ?>
            		    </h6>
            		    <hr>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </ul>