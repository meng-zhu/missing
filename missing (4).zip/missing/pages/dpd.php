<?php 
    header("Content-Type:text/html; charset=utf-8");
    $pId=$_GET['id'];
    
    require_once "config.php";
	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
	$result = mysql_query ( "set names utf8", $link );
	mysql_selectdb ( $dbname, $link );

    $cmd_select = "SELECT * FROM `pet` WHERE `pId`='$pId'";
	$result_select=mysql_query($cmd_select,$link);
	$row = mysql_fetch_assoc($result_select);
	$images = $row["images"];
	//echo $images;
	if($images!="animal-paw-print (1).png"){
	     unlink("images/$images");//將檔案刪除
	}
   
 	$cmd = "DELETE FROM `pet` WHERE `pId` ='$pId'";
 	
	$result=mysql_query($cmd,$link);
	header("Location:pdm.php");
?>
