<?php
    $result = "";
    if (!isset($_GET["city"])) {
    	die("no city found.");
    }
    $city = $_GET["city"];

   if($city != "請選擇縣市"){
        $cmd =  "select * from gov where gName like '".$city."%'";
    }else{
        $cmd = "select * from gov";
    }
    //$result = $cmd;
	require_once "config.php";

	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
	$result = mysql_query ( "set names utf8", $link );
	mysql_selectdb ( $dbname, $link );
	$result=mysql_query($cmd,$link);

    //echo $result;
    
?>
    <TABLE BORDER="1"  WIDTH="100%"> 
        <TR align="center"><TD>收容所名稱</TD><TD>地址</TD><TD>聯絡電話</TD><TD>服務時間</TD>
        <?php while ($row = mysql_fetch_assoc($result)){ ?>
        <TR align="center"><TD>
            <?php echo $row['gName']?>
        </TD><TD>  <?php echo $row['gPlace']?></TD><TD>  <?php echo $row['gPhone']?></TD><TD>  <?php echo $row['gService']?></TD></TR>
        <?php } ?>
    </TABLE>
 