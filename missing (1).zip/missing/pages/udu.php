<?php 
    session_start();
    header("Content-Type:text/html; charset=utf-8");
    
    $uId = $_SESSION['uId'];
    $password=$_POST["password"];
    $password1=$_POST["password1"];
    $name=$_POST["name"];
    $phone=$_POST["phone"];
    
    if($password != $password1){
        echo "確認密碼錯誤";
        echo '<meta http-equiv=REFRESH CONTENT=1;url=mdm.php>';

    }else{
        require_once "config.php";

    	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
    	$result = mysql_query ( "set names utf8", $link );
    	mysql_selectdb ( $dbname, $link );
        
     	$cmd = "UPDATE `user` SET `password`='$password',`name`='$name',`phone`='$phone' WHERE `uId` ='$uId'";
    	$result=mysql_query($cmd,$link);
        echo "會員資料以成功變更";
        echo '<meta http-equiv=REFRESH CONTENT=1;url=index.php>';
    }
    
?>

