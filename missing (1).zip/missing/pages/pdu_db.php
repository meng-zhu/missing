<?php 
   session_start();
   $uId = $_SESSION['uId'];
    $pId=$_GET['id'];
    
   header("Content-Type:text/html; charset=utf-8");
  // echo "test<br>";
  //http://www.webtech.tw/info.php?tid=24
  
    $num = $_POST["num"];
    $variety = $_POST["variety"];
    $sex = $_POST["sex"];
    $weight = $_POST["weight"];
    $age = $_POST["age"];
    $color = $_POST["color"];
    $orther = $_POST["orther"];
    $type = $_POST["type"];
    $city = $_POST["city"];
    $place = $_POST["place"];
    $date = $_POST["date"];

    $images = $_FILES["file"]["name"];
    
	require_once "config.php";
	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
	$result = mysql_query ( "set names utf8", $link );
	mysql_selectdb ( $dbname, $link );
        
    if($images!=null){
        move_uploaded_file($_FILES["file"]["tmp_name"],"images/".$_FILES["file"]["name"]);
        $cmd = "UPDATE `pet` SET `num`='$num',`sex`='$sex',`variety`='$variety',`weight`='$weight',`age`='$age',`color`='$color',`orther`='$orther',`images`='$images',`type`='$type',`city`='$city',`missingPlace`='$place',`missingDate`='$date'WHERE `pId`='$pId'";
       
    }else{
        $cmd = "UPDATE `pet` SET `num`='$num',`sex`='$sex',`variety`='$variety',`weight`='$weight',`age`='$age',`color`='$color',`orther`='$orther',`type`='$type',`city`='$city',`missingPlace`='$place',`missingDate`='$date'WHERE `pId`='$pId'";

    }
       
	$result=mysql_query($cmd,$link);
    echo '<meta http-equiv=REFRESH CONTENT=1;url=index.php>';

?>

