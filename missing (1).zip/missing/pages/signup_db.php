<?php
    header("Content-Type:text/html; charset=utf-8");
   
    if(!(isset($_POST["email"])&isset($_POST["password"])&isset($_POST["name"]))){
        	echo "nodata";
    }
    $email=$_POST["email"];
    $password=$_POST["password"];
    $name=$_POST["name"];
    $phone=$_POST["phone"];
    
    //echo $email." ".$password." ".$name;
	
	require_once "config.php";

	$link = mysql_connect ( $dbhost, $dbuser, $dbpass ) or die ( mysql_error () );
	$result = mysql_query ( "set names utf8", $link );
	mysql_selectdb ( $dbname, $link );
	//先select看看資料庫中是否有一樣的信箱已經註冊過
 	$cmd = "SELECT * FROM `user` WHERE `email` = '$email'";
	$result=mysql_query($cmd,$link);
    if (mysql_num_rows($result) < 1){
        //echo "尚未註冊過";
        //此信箱可以註冊
        $cmd = "INSERT INTO `user`(`email`, `password`, `name`, `phone`) VALUES ('$email','$password','$name','$phone')";
        $result=mysql_query($cmd,$link);
        echo "已成功註冊.<BR>\n<a href='login.html'>不想等待請按此</a>"; ;
        header("Refresh:0; url=https://missing-meng-zhu.c9users.io/missing/pages/login.php"); 
     
        exit;
    }else{
        echo "此信箱已註冊過";
        header("Refresh:0; url=https://missing-meng-zhu.c9users.io/missing/pages/signup.php"); 

      
    }
    echo $result;



?>